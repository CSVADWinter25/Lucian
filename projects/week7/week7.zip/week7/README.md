## Project 7 Readme

For this project I started by modifying the 1d noise patch. I changed how the line drawing process is set up and set the colors to select from a random teal-blue-green pallete. Line collections are drawn within a for loop if the mouse is pressed. The lines are drawn based on mouse position and randomized locations. At the beginning of the mouse pressing action, the opacity is very low. Over time, it gets darker. Outside of the loop it resets.
